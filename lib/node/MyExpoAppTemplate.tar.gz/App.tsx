import App from './src/Application';

export default App;
